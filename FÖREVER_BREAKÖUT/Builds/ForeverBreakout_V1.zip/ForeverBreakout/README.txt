Created by Samuel Einheri

-- Controls (In Game) --
Left/Right Arrow Key = Move Left/Right
Space = Launch Ball
C (Hold) = "Debug" Window
Esc = Return To Main Menu

-- Controls (In Main Menu) --
Enter = Play Game
H = How To Play Menu
Esc (In How To Play Menu) = Return to Main Menu
Esc (In Main Menu) = Quit Game